package com.noor.messenger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NoorApp() }
    }
}

private enum class Screen { PHONE, CHATS }

@Composable
fun NoorApp() {
    var screen by remember { mutableStateOf(Screen.PHONE) }
    var phone by remember { mutableStateOf("") }
    var language by remember { mutableStateOf("ar") }

    MaterialTheme(
        colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF087D59))
    ) {
        Surface(Modifier.fillMaxSize()) {
            CompositionLocalProvider(LocalLayoutDirection provides
                if (language == "ar") androidx.compose.ui.unit.LayoutDirection.Rtl
                else androidx.compose.ui.unit.LayoutDirection.Ltr
            ) {
                when (screen) {
                    Screen.PHONE -> PhoneLoginScreen(
                        phone = phone,
                        onPhoneChange = { phone = it },
                        language = language,
                        onLanguageChange = { language = it },
                        onContinue = { screen = Screen.CHATS }
                    )
                    Screen.CHATS -> ChatListScreen(language = language)
                }
            }
        }
    }
}

@Composable
private fun PhoneLoginScreen(
    phone: String,
    onPhoneChange: (String) -> Unit,
    language: String,
    onLanguageChange: (String) -> Unit,
    onContinue: () -> Unit
) {
    val arabic = language == "ar"
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Noor", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold)
        Text(if (arabic) "نور يجمعنا" else "Noor connects us")
        Spacer(Modifier.height(32.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = { onLanguageChange("ar") }) { Text("العربية") }
            TextButton(onClick = { onLanguageChange("de") }) { Text("Deutsch") }
        }
        OutlinedTextField(
            value = phone,
            onValueChange = onPhoneChange,
            label = { Text(if (arabic) "رقم الهاتف مع رمز الدولة" else "Telefonnummer mit Ländervorwahl") },
            placeholder = { Text("+49 151 12345678") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = onContinue,
            enabled = phone.trim().length >= 8,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (arabic) "إرسال رمز التحقق" else "Bestätigungscode senden")
        }
        Spacer(Modifier.height(8.dp))
        Text(
            if (arabic) "واجهة تجريبية: ربط SMS بـ Firebase مطلوب قبل الاستخدام الحقيقي."
            else "Demo: Firebase-SMS muss vor dem echten Einsatz verbunden werden.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

private data class DemoChat(val name: String, val preview: String, val time: String)

@Composable
private fun ChatListScreen(language: String) {
    val arabic = language == "ar"
    val chats = listOf(
        DemoChat("أحمد", "أهلاً بك في نور 👋", "10:30"),
        DemoChat("محمد", "أرسلت لك صورة", "09:45"),
        DemoChat("Familie", "Bis später!", "Gestern")
    )
    var selected by remember { mutableStateOf<DemoChat?>(null) }

    if (selected != null) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            TextButton(onClick = { selected = null }) { Text(if (arabic) "رجوع" else "Zurück") }
            Text(selected!!.name, style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(12.dp))
            Text(if (arabic) "هذه شاشة محادثة تجريبية. الرسائل الحقيقية تحتاج Firestore."
                 else "Demo-Chat. Echte Nachrichten benötigen Firestore.")
        }
    } else {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text("Noor", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text(if (arabic) "المحادثات" else "Chats", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(12.dp))
            LazyColumn {
                items(chats) { chat ->
                    ListItem(
                        headlineContent = { Text(chat.name) },
                        supportingContent = { Text(chat.preview) },
                        trailingContent = { Text(chat.time) },
                        leadingContent = {
                            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer) {
                                Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                                    Text(chat.name.take(1), fontWeight = FontWeight.Bold)
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}
